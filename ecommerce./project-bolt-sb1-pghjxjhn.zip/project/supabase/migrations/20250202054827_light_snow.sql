/*
  # E-commerce Schema Setup

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `price` (numeric)
      - `image_url` (text)
      - `category` (text)
      - `stock` (integer)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `products` table
    - Add policy for public read access
    - Add policy for authenticated users to manage products
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  image_url text NOT NULL,
  category text NOT NULL,
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Allow public read access"
  ON products
  FOR SELECT
  TO public
  USING (true);

-- Allow authenticated users to manage products
CREATE POLICY "Allow authenticated users to manage products"
  ON products
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert sample products
INSERT INTO products (name, description, price, image_url, category, stock) VALUES
  ('Modern Desk Lamp', 'Sleek LED desk lamp with adjustable brightness', 49.99, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c', 'Lighting', 50),
  ('Wireless Earbuds', 'Premium wireless earbuds with noise cancellation', 129.99, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df', 'Electronics', 30),
  ('Leather Backpack', 'Handcrafted genuine leather backpack', 89.99, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62', 'Accessories', 20),
  ('Smart Watch', 'Fitness tracking smartwatch with heart rate monitor', 199.99, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a', 'Electronics', 15),
  ('Coffee Maker', 'Programmable coffee maker with thermal carafe', 79.99, 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6', 'Appliances', 25),
  ('Yoga Mat', 'Non-slip exercise yoga mat with carrying strap', 29.99, 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f', 'Fitness', 100);